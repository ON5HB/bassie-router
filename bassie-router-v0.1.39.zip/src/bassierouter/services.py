"""Renderers voor dnsmasq, sysctl, PPPoE, link-setup en systemd-units."""
from __future__ import annotations

import re
import shlex
import subprocess
from pathlib import Path

from . import __release_date__, __version__
from .config import Config

BEGIN = "# BEGIN Bassie-Router (automatisch gegenereerd)"
END = "# END Bassie-Router"


def _q(value: str) -> str:
    """Escape voor gebruik tussen dubbele quotes in PPP-config."""
    return value.replace("\\", "\\\\").replace('"', '\\"')


def render_hostname(cfg: Config) -> str:
    return cfg.hostname + "\n"


def render_hosts(cfg: Config, existing: str, old_hostname: str = "") -> str:
    """Bewaar /etc/hosts en vervang alleen de oude hostname."""
    lines = existing.splitlines() if existing.strip() else ["127.0.0.1 localhost"]
    result = []
    found = False
    for line in lines:
        stripped = line.strip()
        if stripped and not stripped.startswith("#"):
            parts = [cfg.hostname if part == old_hostname else part for part in stripped.split()]
            line = " ".join(parts)
            if "127.0.1.1" in parts and cfg.hostname in parts:
                found = True
        result.append(line)
    if not found:
        result.append(f"127.0.1.1 {cfg.hostname}")
    return "\n".join(result) + "\n"


def render_motd(cfg: Config) -> str:
    """Statisch welkomstbericht. Het IP komt uit update-motd.d (actueel)."""
    return (
        "\n"
        "============================================================\n"
        f" Bassie-Router v{__version__} · {__release_date__}\n"
        " Debian 13 · IPv4-only · open source & gratis (MIT)\n"
        "\n"
        " Samen gebouwd door Bas Heijermans (ON5HB, radioamateur):\n"
        " hardware, testen en koers — en Big Pickle, de AI-assistent\n"
        " in OpenCode: https://opencode.ai\n"
        "\n"
        " Login: root + je SSH-wachtwoord (sessie 30 min)\n"
        " CLI: bassie-router status · bassie-router apply --dry-run\n"
        "============================================================\n"
    )


def render_motd_ip_script(cfg: Config) -> str:
    """Toont bij elke login het IP dat de LAN-bridge nú echt heeft."""
    bridge = shlex.quote(cfg.interfaces.lan_bridge)
    port = cfg.gui.port
    return f"""#!/bin/sh
# Gegenereerd door Bassie-Router - actueel GUI-adres bij elke login.
IP=$(/usr/sbin/ip -4 -o addr show dev {bridge} scope global 2>/dev/null | \\
    awk '{{for (i = 1; i <= NF; i++) if ($i == "inet") {{split($(i + 1), a, "/"); print a[1]; exit}}}}')
if [ -z "$IP" ]; then
    echo "GUI: http://127.0.0.1:{port} (alleen lokaal; via SSH -L {port}:127.0.0.1:{port})"
else
    echo "GUI: http://$IP:{port}"
fi
"""


def render_sysctl(cfg: Config) -> str:
    udp = cfg.firewall.udp_nat_timeout
    udp_lines = ""
    if udp:
        udp_lines = (
            f"net.netfilter.nf_conntrack_udp_timeout={udp}\n"
            f"net.netfilter.nf_conntrack_udp_timeout_stream={udp}\n"
        )
    return (
        "# Gegenereerd door Bassie-Router - IPv4-only router\n"
        "net.ipv4.ip_forward=1\n"
        "net.ipv4.conf.all.rp_filter=2\n"
        "net.ipv4.conf.default.rp_filter=2\n"
        "net.ipv4.conf.all.accept_redirects=0\n"
        "net.ipv6.conf.all.disable_ipv6=1\n"
        "net.ipv6.conf.default.disable_ipv6=1\n"
        "net.ipv6.conf.lo.disable_ipv6=1\n"
        + udp_lines
    )


def render_dnsmasq(cfg: Config) -> str:
    i = cfg.interfaces
    lines = [
        "# Gegenereerd door Bassie-Router - DNS (IPv4)",
        f"interface={i.lan_iface}",
        "bind-interfaces",
        "no-resolv",
        "domain-needed",
        "bogus-priv",
        f"domain={i.dns_domain}",
        "expand-hosts",
    ]
    if i.dhcp_enabled:
        lines += [
            "# DHCP-server aan: de router bedient het LAN zelf.",
            f"listen-address={i.lan_ip}",
            "dhcp-authoritative",
            f"dhcp-range={i.dhcp_start},{i.dhcp_end},{i.dhcp_lease}",
            f"dhcp-option=3,{i.lan_ip}",
            f"dhcp-option=6,{i.lan_ip}",
        ]
    else:
        lines.append(
            "# DHCP-server uit: geen dhcp-range en geen vast listen-address; "
            "DNS luistert op de adressen van de bridge."
        )
    lines += [f"server={s}" for s in i.dns_upstream]
    return "\n".join(lines) + "\n"


def render_links_script(cfg: Config) -> str:
    i = cfg.interfaces
    ports = " ".join(shlex.quote(p) for p in i.lan_ports)
    bootstrap = "0" if cfg.bootstrapped else "1"
    vlan_block = ""
    if i.wan_vlan_id:
        vlan_block = f"""
if ! exists "{i.wan_iface}" && exists "$WAN"; then
    $IP link add link "$WAN" name "{i.wan_iface}" type vlan id {i.wan_vlan_id} 2>/dev/null || true
fi
if exists "{i.wan_iface}"; then
    $IP link set dev "{i.wan_iface}" up 2>/dev/null || true
fi
"""
    # Na de eerste setup: poorten die niet als LAN gekozen zijn, uit de bridge halen.
    detach_block = ""
    if cfg.bootstrapped:
        detach_block = """
# Alleen de gekozen LAN-poorten blijven in de bridge; de rest wordt WAN.
for port in $ALL_PORTS; do
    case " $PORTS " in
        *" $port "*) continue ;;
    esac
    if exists "$port"; then
        $IP link set dev "$port" nomaster 2>/dev/null || true
        $IP addr flush dev "$port" 2>/dev/null || true
        $IP -6 addr flush dev "$port" 2>/dev/null || true
        $IP link set dev "$port" up 2>/dev/null || true
    fi
done
"""
    if cfg.bootstrapped and i.dhcp_enabled:
        addr_block = f"""
# DHCP-server aan: definitief LAN-adres (IPv4, geen VLAN); ook IPv6 resten weghalen.
$IP addr flush dev "$BR" 2>/dev/null || true
$IP -6 addr flush dev "$BR" 2>/dev/null || true
$IP addr add "${{{'LAN_IP'}}}/${{{'PREFIX'}}}" dev "$BR"
"""
    else:
        addr_block = """
# DHCP-server uit (ook tijdens de initiele setup): bridge is DHCP-klant.
# bassie-lan-dhcp.service houdt de lease actief en probeert opnieuw als de
# DHCP-server bij boot nog niet bereikbaar is. Hier alleen oude adressen weg.
$IP addr flush dev "$BR" 2>/dev/null || true
$IP -6 addr flush dev "$BR" 2>/dev/null || true
"""
    if i.wan_mode == "dhcp":
        wan_addr_block = """
# WAN dhcp-client: adres en default route komen van de provider/modem.
$IP addr flush dev "$WAN_IFACE" 2>/dev/null || true
$IP -6 addr flush dev "$WAN_IFACE" 2>/dev/null || true
if [ -x /usr/sbin/dhclient ] && command -v timeout >/dev/null 2>&1; then
    timeout 12 /usr/sbin/dhclient -4 -1 "$WAN_IFACE" >/dev/null 2>&1 || true
fi
"""
    elif i.wan_mode == "static":
        wan_addr_block = f"""
# WAN statisch: adres, gateway en (optioneel) DNS van de provider.
$IP addr flush dev "$WAN_IFACE" 2>/dev/null || true
$IP -6 addr flush dev "$WAN_IFACE" 2>/dev/null || true
$IP addr add "{i.wan_static_ip}/{i.wan_static_prefix}" dev "$WAN_IFACE"
$IP route replace default via "{i.wan_static_gateway}" dev "$WAN_IFACE"
"""
        if i.wan_static_dns:
            dns_commands = "\n".join(
                f'    echo "nameserver {shlex.quote(server)}"' for server in i.wan_static_dns
            )
            wan_addr_block += f"""
# Alleen in statische modus beheert niemand anders resolv.conf.
{{
    echo "# Gegenereerd door Bassie-Router"
{dns_commands}
}} > /etc/resolv.conf
"""
    else:
        # PPPoE: de WAN-poort blijft een laag-2 interface; pppd/ppp0 doet het adres.
        wan_addr_block = ""
    if wan_addr_block:
        wan_block = (
            '\nif [ "$BOOTSTRAP" = "0" ] && exists "$WAN_IFACE"; then\n'
            + wan_addr_block
            + "fi\n"
        )
    else:
        wan_block = ""
    # De bridge kan (met DHCP-server uit) ook een default route van een andere
    # DHCP-server krijgen. Die moet niet winnen van de WAN-verbinding.
    if i.wan_mode == "static":
        wan_route_fix = f"""
# Default route via WAN herstellen na de DHCP-klant op de bridge.
$IP route del default dev "$BR" 2>/dev/null || true
$IP route replace default via "{i.wan_static_gateway}" dev "$WAN_IFACE"
"""
    elif i.wan_mode == "dhcp":
        wan_route_fix = """
# Geen default route via de LAN-bridge; WAN is de uplink.
$IP route del default dev "$BR" 2>/dev/null || true
"""
    else:
        wan_route_fix = ""
    return f"""#!/bin/sh
# Gegenereerd door Bassie-Router - maakt bridge, WAN-VLAN en LAN-IP aan.
# Geen 'set -e': een mislukte link-actie mag nooit de rest (LAN-IP) afbreken.
set -u
IP=/usr/sbin/ip
WAN="{i.wan}"
WAN_IFACE="{i.wan_iface}"
WAN_MODE="{i.wan_mode}"
BR="{i.lan_bridge}"
LAN_IP="{i.lan_ip}"
PREFIX="{i.lan_prefix}"
PORTS="{ports}"
BOOTSTRAP="{bootstrap}"

exists() {{ $IP link show dev "$1" >/dev/null 2>&1 || return 1; }}

# Bridge eerst, en met retry: als de module of udev nog niet klaar is,
# mag de rest van het script niet zonder bridge verdergaan.
n=0
while ! exists "$BR"; do
    command -v modprobe >/dev/null 2>&1 && modprobe bridge >/dev/null 2>&1 || true
    $IP link add name "$BR" type bridge 2>/dev/null || true
    n=$((n + 1))
    [ "$n" -ge 10 ] && break
    sleep 1
done

# Daarna kort wachten op definitieve kaartnamen (enp* i.p.v. eth*).
command -v udevadm >/dev/null 2>&1 && timeout 10 udevadm settle >/dev/null 2>&1 || true

# Fysieke ethernetpoorten, exclusief loopback, bridge, WAN en virtuele apparaten.
ALL_PORTS=""
for entry in /sys/class/net/*; do
    name=${{entry##*/}}
    case "$name" in
        lo|"$BR"|"$WAN"|ppp*|veth*|docker*|virbr*|wl*|*.*) continue ;;
    esac
    ALL_PORTS="$ALL_PORTS $name"
done

for port in $PORTS; do
    if exists "$port"; then
        # Een oud DHCP-adres op de fysieke poort moet weg vóór het masteren,
        # anders staat hetzelfde IP zowel op de poort als op de bridge.
        $IP addr flush dev "$port" 2>/dev/null || true
        $IP -6 addr flush dev "$port" 2>/dev/null || true
        $IP link set dev "$port" master "$BR" 2>/dev/null || true
        $IP link set dev "$port" up 2>/dev/null || true
    fi
done
{detach_block}{vlan_block}
if exists "$WAN"; then
    $IP link set dev "$WAN" up 2>/dev/null || true
    if [ "$BOOTSTRAP" = "0" ]; then
        $IP addr flush dev "$WAN" 2>/dev/null || true
    fi
fi
{wan_block}$IP link set dev "$BR" up 2>/dev/null || true
{addr_block}{wan_route_fix}"""


def render_client_options(cfg: Config) -> str:
    c = cfg.pppoe_client
    lines = [
        "# Gegenereerd door Bassie-Router - PPPoE-client",
        "noipdefault",
        "defaultroute",
        "replacedefaultroute",
        "hide-password",
        "noauth",
        "persist",
        "maxfail 0",
        "lcp-echo-interval 30",
        "lcp-echo-failure 4",
        f"mtu {c.mtu}",
        "plugin rp-pppoe.so",
        c.iface(cfg),
        f'user "{_q(c.username)}"',
    ]
    if c.service_name:
        lines.append(f'rp-pppoe-service "{_q(c.service_name)}"')
    if c.usepeerdns:
        lines.append("usepeerdns")
    if c.demand:
        lines.append("demand")
    lines.append("")
    return "\n".join(lines)


def render_secrets_block(cfg: Config) -> str:
    lines = [BEGIN]
    c = cfg.pppoe_client
    if c.enabled:
        lines.append(f'"{_q(c.username)}" * "{_q(c.password)}" *')
    lines += [END, ""]
    return "\n".join(lines)


def merge_managed_file(existing: str, block: str) -> str:
    """Vervangt het door Bassie-Router beheerde blok, laat de rest intact."""
    if BEGIN in existing and END in existing:
        before, rest = existing.split(BEGIN, 1)
        _, after = rest.split(END, 1)
        existing = before + after.lstrip("\n")
    if existing and not existing.endswith("\n"):
        existing += "\n"
    return existing + block


def _cmd_output(argv: list[str]) -> str:
    try:
        return subprocess.run(
            argv, capture_output=True, text=True, timeout=5, check=False
        ).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return ""


def _grub_boot_info() -> dict[str, str]:
    """Kernelpaden en UUID's voor de factory-reset-menuentry."""
    root_dev = _cmd_output(["findmnt", "-no", "SOURCE", "/"])
    boot_dev = _cmd_output(["findmnt", "-no", "SOURCE", "/boot"]) or root_dev
    root_uuid = _cmd_output(["blkid", "-s", "UUID", "-o", "value", root_dev]) if root_dev else ""
    boot_uuid = _cmd_output(["blkid", "-s", "UUID", "-o", "value", boot_dev]) if boot_dev else ""
    separate = bool(boot_dev and root_dev and boot_dev != root_dev)
    if separate:
        # Bij een aparte /boot-partitie zijn de /vmlinuz-symlinks niet leesbaar
        # voor GRUB. Dan nemen we de nieuwste kernel; na een update moet de
        # entry eventueel opnieuw worden toegepast.
        kernels = sorted(
            Path("/boot").glob("vmlinuz-*"),
            key=lambda p: [int(x) if x.isdigit() else x for x in re.split(r"(\d+)", p.name)],
        )
        kernel = kernels[-1].name if kernels else "vmlinuz"
        version = kernel[len("vmlinuz-"):] if kernel.startswith("vmlinuz-") else ""
        initrd = f"initrd.img-{version}" if version else "initrd.img"
        search_uuid, prefix = boot_uuid, ""
    else:
        # Standaard Debian: /vmlinuz en /initrd.img zijn symlinks die bij
        # elke kernelupdate automatisch meewisselen.
        search_uuid, prefix, kernel, initrd = root_uuid, "", "vmlinuz", "initrd.img"
    return {
        "search_uuid": search_uuid,
        "root_uuid": root_uuid,
        "separate": separate,
        "kernel": f"{prefix}/{kernel}" if kernel.startswith("/") else f"/{kernel}",
        "initrd": f"{prefix}/{initrd}" if initrd.startswith("/") else f"/{initrd}",
    }


def render_grub_factory(existing: str) -> str:
    """Voegt een GRUB-keuze toe die de router als verse installatie start."""
    info = _grub_boot_info()
    search = (
        f"search --no-floppy --fs-uuid --set=root {info['search_uuid']}\n    "
        if info["search_uuid"] else ""
    )
    root = f"root=UUID={info['root_uuid']} " if info["root_uuid"] else ""
    block = (
        f"{BEGIN}\n"
        "# Bassie-Router: start met standaardwaarden (configs worden verwijderd).\n"
        "menuentry 'Bassie-Router: verse installatie (factory reset)' "
        "--class gnu-linux --class os {\n"
        f"    {search}"
        f"linux {info['kernel']} {root}ro quiet bassie_factory=1\n"
        f"    initrd {info['initrd']}\n"
        "}\n"
        f"{END}\n"
    )
    return merge_managed_file(existing, block)


def render_factory_boot_script(cfg: Config) -> str:
    """Verwijdert onze configs en start met standaardwaarden bij GRUB-keuze."""
    return """#!/bin/sh
# Gegenereerd door Bassie-Router - factory reset via GRUB-menukeuze.
set -u
grep -qw 'bassie_factory=1' /proc/cmdline 2>/dev/null || exit 0
echo "Bassie-Router: factory reset bij boot (standaardwaarden)."

rm -f /etc/bassie-router/config.json \\
    /var/lib/bassie-router/applied-config.json \\
    /etc/dnsmasq.d/bassie-router.conf \\
    /etc/nftables.conf \\
    /etc/sysctl.d/99-bassie-router.conf \\
    /etc/ppp/peers/bassie-isp \\
    /etc/update-motd.d/40-bassie-router-ip

PYTHONPATH=/opt/bassie-router/src /usr/bin/python3 - <<'PY'
from pathlib import Path
from bassierouter.config import Config, save_config

cfg = Config()
cfg.bootstrapped = False
cfg.interfaces.wan = "kies-poort"
ports = []
for entry in sorted(Path("/sys/class/net").iterdir()):
    name = entry.name
    if name in ("lo", cfg.interfaces.lan_bridge):
        continue
    if name.startswith(("ppp", "veth", "docker", "virbr", "wl")) or "." in name:
        continue
    ports.append(name)
cfg.interfaces.lan_ports = ports or ["eth1"]
cfg.firewall.allow_gui_bootstrap = True
cfg.gui.bind = "127.0.0.1"
save_config(cfg, "/etc/bassie-router/config.json")
PY

for what in nft dnsmasq sysctl links; do
    PYTHONPATH=/opt/bassie-router/src /usr/bin/python3 -m bassierouter \\
        render "$what" > "/tmp/bassie-factory-$what" 2>/dev/null || continue
    case "$what" in
        nft) cp "/tmp/bassie-factory-$what" /etc/nftables.conf ;;
        dnsmasq) cp "/tmp/bassie-factory-$what" /etc/dnsmasq.d/bassie-router.conf ;;
        sysctl) cp "/tmp/bassie-factory-$what" /etc/sysctl.d/99-bassie-router.conf ;;
        links) cp "/tmp/bassie-factory-$what" /usr/local/sbin/bassie-setup-links; chmod 0755 /usr/local/sbin/bassie-setup-links ;;
    esac
    rm -f "/tmp/bassie-factory-$what"
done
systemctl enable --now bassie-links.service bassie-lan-dhcp.service bassie-router.service >/dev/null 2>&1 || true
"""


def render_lan_dhcp_script(cfg: Config) -> str:
    """DHCP-klant op de LAN-bridge die blijft proberen tot er een lease is."""
    return f"""#!/bin/sh
# Gegenereerd door Bassie-Router - DHCP-klant voor de LAN-bridge.
# 'bassie-links.service' maakt de bridge; deze service houdt het adres actief.
set -u
mkdir -p /var/lib/bassie-router
exec /usr/sbin/dhclient -4 -d -lf /var/lib/bassie-router/dhclient.leases \\
    {shlex.quote(cfg.interfaces.lan_bridge)}
"""


def render_cpu_script(cfg: Config) -> str:
    """Genereert het CPU-profiel: governor en min/max frequentie via cpupower."""
    s = cfg.system
    governor = shlex.quote(s.cpu_governor)
    minimum = s.cpu_min_mhz or ""
    maximum = s.cpu_max_mhz or ""
    return f"""#!/bin/sh
# Gegenereerd door Bassie-Router - CPU-profiel (zuinig, minder warmte).
GOV={governor}
MIN="{minimum}"
MAX="{maximum}"
CPUPOWER=""
for candidate in /usr/bin/cpupower /usr/local/bin/cpupower; do
    [ -x "$candidate" ] && CPUPOWER="$candidate" && break
done
if [ -n "$CPUPOWER" ]; then
    [ -n "$GOV" ] && $CPUPOWER frequency-set --governor "$GOV" >/dev/null 2>&1 || true
    if [ -n "$MIN$MAX" ]; then
        args=""
        [ -n "$MIN" ] && args="$args --min ${{MIN}}MHz"
        [ -n "$MAX" ] && args="$args --max ${{MAX}}MHz"
        $CPUPOWER frequency-set $args >/dev/null 2>&1 || true
    fi
fi
CPUFREQSET=$(command -v cpufreq-set 2>/dev/null || true)
if [ -n "$CPUFREQSET" ]; then
    [ -n "$GOV" ] && $CPUFREQSET -g "$GOV" >/dev/null 2>&1 || true
    [ -n "$MIN" ] && $CPUFREQSET -d "${{MIN}}MHz" >/dev/null 2>&1 || true
    [ -n "$MAX" ] && $CPUFREQSET -u "${{MAX}}MHz" >/dev/null 2>&1 || true
fi
# Laatste redmiddel: rechtstreeks sysfs (geen package nodig).
for dir in /sys/devices/system/cpu/cpu*/cpufreq; do
    [ -d "$dir" ] || continue
    if [ -n "$GOV" ] && [ -w "$dir/scaling_governor" ]; then
        echo "$GOV" > "$dir/scaling_governor" 2>/dev/null || true
    fi
    if [ -n "$MIN" ] && [ -w "$dir/scaling_min_freq" ]; then
        echo $((MIN * 1000)) > "$dir/scaling_min_freq" 2>/dev/null || true
    fi
    if [ -n "$MAX" ] && [ -w "$dir/scaling_max_freq" ]; then
        echo $((MAX * 1000)) > "$dir/scaling_max_freq" 2>/dev/null || true
    fi
done
"""


def render_systemd_units(cfg: Config) -> dict[str, str]:
    return {
        "/etc/systemd/system/bassie-links.service": (
            "[Unit]\n"
            "Description=Bassie-Router netwerklinks (bridge, WAN-VLAN, LAN-IP)\n"
            "DefaultDependencies=no\n"
            "After=local-fs.target\n"
            "\n"
            "[Service]\n"
            "Type=oneshot\n"
            "RemainAfterExit=yes\n"
            "ExecStart=/usr/local/sbin/bassie-setup-links\n"
            "\n"
            "[Install]\n"
            "WantedBy=multi-user.target\n"
        ),
        "/etc/systemd/system/bassie-factory-boot.service": (
            "[Unit]\n"
            "Description=Bassie-Router factory reset bij GRUB-keuze\n"
            "DefaultDependencies=no\n"
            "After=local-fs.target\n"
            "Before=bassie-links.service bassie-lan-dhcp.service "
            "bassie-router.service\n"
            "\n"
            "[Service]\n"
            "Type=oneshot\n"
            "RemainAfterExit=yes\n"
            "ExecStart=/usr/local/sbin/bassie-factory-boot\n"
            "\n"
            "[Install]\n"
            "WantedBy=multi-user.target\n"
        ),
        "/etc/systemd/system/bassie-lan-dhcp.service": (
            "[Unit]\n"
            "Description=Bassie-Router LAN DHCP-client (blijft proberen)\n"
            "After=bassie-links.service\n"
            "Requires=bassie-links.service\n"
            "\n"
            "[Service]\n"
            "Type=simple\n"
            "ExecStart=/usr/local/sbin/bassie-lan-dhcp\n"
            "Restart=always\n"
            "RestartSec=5\n"
            "\n"
            "[Install]\n"
            "WantedBy=multi-user.target\n"
        ),
        "/etc/systemd/system/bassie-cpu.service": (
            "[Unit]\n"
            "Description=Bassie-Router CPU-profiel (cpupower)\n"
            "After=bassie-links.service\n"
            "\n"
            "[Service]\n"
            "Type=oneshot\n"
            "RemainAfterExit=yes\n"
            "ExecStart=/usr/local/sbin/bassie-cpu-profile\n"
            "\n"
            "[Install]\n"
            "WantedBy=multi-user.target\n"
        ),
        "/etc/systemd/system/bassie-router.service": (
            "[Unit]\n"
            "Description=Bassie-Router HTTP GUI\n"
            "After=network-online.target bassie-links.service bassie-lan-dhcp.service\n"
            "Wants=network-online.target\n"
            "\n"
            "[Service]\n"
            "Type=simple\n"
            "User=root\n"
            "Environment=PYTHONPATH=/opt/bassie-router/src\n"
            "Environment=BASSIE_CONFIG=/etc/bassie-router/config.json\n"
            "Environment=BASSIE_GUI_PAM=1\n"
            "ExecStart=/usr/bin/python3 -m bassierouter serve\n"
            "Restart=on-failure\n"
            "RestartSec=3\n"
            "\n"
            "[Install]\n"
            "WantedBy=multi-user.target\n"
        ),
        "/etc/systemd/system/bassie-pppoe-client.service": (
            "[Unit]\n"
            "Description=Bassie-Router PPPoE-client\n"
            "After=bassie-links.service\n"
            "Requires=bassie-links.service\n"
            "\n"
            "[Service]\n"
            "Type=simple\n"
            "ExecStart=/usr/sbin/pppd call bassie-isp nodetach\n"
            "ExecStop=/usr/sbin/poff bassie-isp\n"
            "Restart=on-failure\n"
            "RestartSec=5\n"
            "\n"
            "[Install]\n"
            "WantedBy=multi-user.target\n"
        ),
    }
